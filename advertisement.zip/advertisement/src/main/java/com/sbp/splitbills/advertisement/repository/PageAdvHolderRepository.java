package com.sbp.splitbills.advertisement.repository;

import com.sbp.splitbills.advertisement.model.PageAdvHolder;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

@RepositoryRestResource(collectionResourceRel = "advholders", path = "advholders",itemResourceRel = "advholder")
public interface PageAdvHolderRepository extends CrudRepository<PageAdvHolder,Long> {

}
