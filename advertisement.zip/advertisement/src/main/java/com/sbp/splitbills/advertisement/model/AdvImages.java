package com.sbp.splitbills.advertisement.model;

import lombok.Data;

import javax.persistence.*;

@Data
@Entity(name="adv_images")
public class AdvImages extends AbstractEntity {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private long adv_images_id;
  private String imageRef;

  @ManyToOne(fetch = FetchType.LAZY)
  @JoinColumn(name = "adv_id", nullable = false)
  private Advertisement adv_dtls;


}
