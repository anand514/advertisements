package com.sbp.splitbills.advertisement.model;


import lombok.Data;

import javax.persistence.*;

@Data
@Entity(name="page_adv_holder")
public class PageAdvHolder extends AbstractEntity {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private long page_adv_id;
  @ManyToOne(fetch = FetchType.LAZY)
  @JoinColumn(name = "page_id", nullable = false)
  private PageMaster page_master;
  @ManyToOne(fetch = FetchType.LAZY)
  @JoinColumn(name = "adv_type_id", nullable = false)
  private MasterTypes master_types;
  private double bracketWidth;
  private double bracketHeight;




}
