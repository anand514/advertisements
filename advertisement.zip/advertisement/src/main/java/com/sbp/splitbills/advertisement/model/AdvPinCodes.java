package com.sbp.splitbills.advertisement.model;

import lombok.Data;

import javax.persistence.*;

@Data
@Entity(name="adv_pincodes")
public class AdvPinCodes extends AbstractEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long adv_pincodes_id;

    private String pincode;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "adv_id", nullable = false)
    private Advertisement adv_dtls;


}
