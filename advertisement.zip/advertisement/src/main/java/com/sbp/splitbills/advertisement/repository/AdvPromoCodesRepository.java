package com.sbp.splitbills.advertisement.repository;

import com.sbp.splitbills.advertisement.model.AdvPromoCodes;
import com.sbp.splitbills.advertisement.model.Advertisement;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

@RepositoryRestResource(collectionResourceRel = "promocodes", path = "promocodes",itemResourceRel = "promocode")
public interface AdvPromoCodesRepository extends CrudRepository<AdvPromoCodes,Long> {
}
