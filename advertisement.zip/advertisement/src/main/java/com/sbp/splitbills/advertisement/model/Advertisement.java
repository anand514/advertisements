package com.sbp.splitbills.advertisement.model;

import javax.persistence.*;
import javax.persistence.Id;

import lombok.Data;

import java.util.Set;

@Data
@Entity(name="adv_dtls")
public class Advertisement extends AbstractEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long adv_dtls_id;
    private String name;
    private String description;
    private java.sql.Timestamp startDate;
    private java.sql.Timestamp endDate;
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "advertisement_type_id", nullable = false)
    private MasterTypes advertisement_type_id;
    private String urlFlag;
    private String url;
    private long priority;
    private long promoTypeId;

    @JoinTable(name="adv_page_holder_mapper",joinColumns = @JoinColumn(
            name = "adv_id",
            referencedColumnName = "adv_dtls_id"
    ),
            inverseJoinColumns = @JoinColumn(
                    name = "page_adv_holder_id",
                    referencedColumnName = "page_adv_id"
            ))
    @ManyToMany
    private Set<PageAdvHolder> advHolders;

    @OneToMany(mappedBy="adv_dtls")
    private Set<AdvImages> advImages;

    @OneToMany(mappedBy="adv_dtls")
    private Set<AdvPinCodes> advPinCodes;

    @OneToMany(mappedBy="adv_dtls")
    private Set<AdvPromoCodes> advPromoCodes;

    @JoinTable(name="adv_user_type_mapper",joinColumns = @JoinColumn(
            name = "adv_id",
            referencedColumnName = "adv_dtls_id"
    ),
            inverseJoinColumns = @JoinColumn(
                    name = "user_type_id",
                    referencedColumnName = "master_type_id"
            ))
    @ManyToMany
    private Set<MasterTypes> masterTypes;






}
