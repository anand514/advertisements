package com.sbp.splitbills.advertisement.repository;

import com.sbp.splitbills.advertisement.model.AdvPinCodes;
import com.sbp.splitbills.advertisement.model.Advertisement;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

@RepositoryRestResource(collectionResourceRel = "pincodes", path = "pincodes",itemResourceRel = "pincodes")
public interface AdvPinCodesRepository extends CrudRepository<AdvPinCodes,Long> {
}
