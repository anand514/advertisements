package com.sbp.splitbills.advertisement.repository;

import com.sbp.splitbills.advertisement.model.AdvImages;
import com.sbp.splitbills.advertisement.model.Advertisement;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

@RepositoryRestResource(collectionResourceRel = "images", path = "images",itemResourceRel = "image")
public interface AdvImagesRepository  extends CrudRepository<AdvImages,Long> {
}
