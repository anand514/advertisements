package com.sbp.splitbills.advertisement.repository;

import com.sbp.splitbills.advertisement.model.PageMaster;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

@RepositoryRestResource(collectionResourceRel = "pages", path = "pages",itemResourceRel = "page")
public interface PageMasterRepository extends CrudRepository<PageMaster,Long> {
}
