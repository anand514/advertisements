package com.sbp.splitbills.advertisement.model;

import lombok.Data;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.MappedSuperclass;


@Data
@MappedSuperclass
public abstract class AbstractEntity {

    private java.sql.Timestamp createDate;
    private java.sql.Timestamp updatedDate;
    private Long createdBy;
    private Long updatedBy;
}
