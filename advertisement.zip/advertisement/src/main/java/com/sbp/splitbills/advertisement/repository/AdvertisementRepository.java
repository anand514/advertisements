package com.sbp.splitbills.advertisement.repository;

import com.sbp.splitbills.advertisement.model.Advertisement;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

@RepositoryRestResource(collectionResourceRel = "advertisements", path = "advertisements",itemResourceRel = "advertisement")
public interface AdvertisementRepository extends CrudRepository<Advertisement,Long> {


}
