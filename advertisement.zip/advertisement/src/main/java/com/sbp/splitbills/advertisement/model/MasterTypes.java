package com.sbp.splitbills.advertisement.model;

import lombok.Data;

import javax.persistence.*;
import java.util.Set;

@Data
@Entity(name="master_types")
public class MasterTypes {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private long master_type_id;
  private String name;
  private String description;
  private String referenceType;
  private String module;
  private Boolean status;

  @OneToMany(mappedBy="master_types")
  private Set<PageAdvHolder> advHolders;

  @ManyToMany(mappedBy = "masterTypes")
  private Set<Advertisement>  advertisements;

  @OneToMany(mappedBy="advertisement_type_id")
  private Set<Advertisement> advertisementSet;






}
