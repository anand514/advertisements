package com.sbp.splitbills.advertisement.model;


import lombok.Data;

import javax.persistence.*;
import java.util.Set;

@Data
@Entity(name="page_master")
public class PageMaster extends AbstractEntity {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private long page_master_id;
  private String pageName;
  private String description;

  @OneToMany(mappedBy="page_master")
  private Set<PageAdvHolder> advHolders;


}
