package com.sbp.splitbills.advertisement.repository;

import com.sbp.splitbills.advertisement.model.MasterTypes;
import com.sbp.splitbills.advertisement.model.PageMaster;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

@RepositoryRestResource(collectionResourceRel = "mastertypes", path = "mastertypes",itemResourceRel = "mastertypes")
public interface MasterTypesRepository extends CrudRepository<MasterTypes,Long> {

}
