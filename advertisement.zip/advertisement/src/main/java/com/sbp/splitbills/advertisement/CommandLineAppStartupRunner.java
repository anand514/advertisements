package com.sbp.splitbills.advertisement;

import com.sbp.splitbills.advertisement.model.*;
import com.sbp.splitbills.advertisement.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

@Component
public class CommandLineAppStartupRunner implements CommandLineRunner {

    @Autowired
    PageMasterRepository masterRepository;

    @Autowired
    MasterTypesRepository masterTypesRepository;

    @Autowired
    PageAdvHolderRepository pageAdvHolderRepository;

    @Autowired
    AdvImagesRepository advImagesRepository;

    @Autowired
    AdvPromoCodesRepository advPromoCodesRepository;

    @Autowired
    AdvPinCodesRepository advPinCodesRepository;

    @Autowired
    AdvertisementRepository advertisementRepository;



    @Override
    public void run(String...args) throws Exception {
//        PageMaster master=new PageMaster();
//        master.setDescription("test");
//        LocalDateTime now = LocalDateTime.now();
//        Timestamp timestamp = Timestamp.valueOf(now);
//        master.setCreateDate(timestamp);
//        master.setUpdatedDate(timestamp);
//
//
//        master.setPageName("testPage");
//
//        masterRepository.save(master);
//
//        MasterTypes masterTypes=new MasterTypes();
//
//        masterTypes.setName("test Master Type");
//
//        masterTypes.setDescription("test description");
//
//        masterTypes.setReferenceType("Promo Codes");
//
//        masterTypes.setModule("Advertisements");
//
//
//
//        masterTypesRepository.save(masterTypes);
//
//        //TODO, load the existing entity with entity manager
//
//        PageAdvHolder pageAdvHolder=new PageAdvHolder();
//
//        pageAdvHolder.setPage_master(master);
//
//        pageAdvHolder.setBracketHeight(100);
//
//        pageAdvHolder.setBracketWidth(200);
//
//        pageAdvHolder.setMaster_types(masterTypes);
//
//        pageAdvHolderRepository.save(pageAdvHolder);
//
//
//        Advertisement advertisement=new Advertisement();
//
//        advertisement.setName("Test Advertisement");
//
//        advertisement.setAdvertisement_type_id(masterTypes);
//
//        Set<PageAdvHolder> holderList=new HashSet<>();
//
//        Set<MasterTypes> masterTypesSet=new HashSet<>();
//
//        masterTypesSet.add(masterTypes);
//
//        advertisement.setMasterTypes(masterTypesSet);
//
//        holderList.add(pageAdvHolder);
//
//        advertisement.setAdvHolders(holderList);
//
//        advertisement.setDescription("Test Advertisement");
//
//        advertisement.setEndDate(timestamp);
//
//        advertisement.setStartDate(timestamp);
//
//        advertisement.setUrl("url");
//
//        advertisement.setUrlFlag("urlflag");
//
//        advertisementRepository.save(advertisement);
//
//        AdvImages advImages=new AdvImages();
//
//        advImages.setImageRef("image_ref");
//
//        advImages.setAdv_dtls(advertisement);
//
//        advImagesRepository.save(advImages);
//
//
//        AdvPinCodes advPinCodes=new AdvPinCodes();
//
//        advPinCodes.setPincode("533344");
//
//        advPinCodes.setAdv_dtls(advertisement);
//
//        advPinCodesRepository.save(advPinCodes);
//
//
//        AdvPromoCodes advPromoCodes=new AdvPromoCodes();
//
//        advPromoCodes.setPromoCode(12345);
//
//        advPromoCodes.setAdv_dtls(advertisement);
//
//        advPromoCodesRepository.save(advPromoCodes);



    }
}
