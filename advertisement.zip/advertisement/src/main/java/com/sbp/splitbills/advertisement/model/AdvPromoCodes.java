package com.sbp.splitbills.advertisement.model;


import lombok.Data;

import javax.persistence.*;

@Data
@Entity(name="adv_promocodes")
public class AdvPromoCodes extends AbstractEntity {
  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private long adv_promocodes_id;
  private long promoCode;
  private long mappedUserId;

  @ManyToOne(fetch = FetchType.LAZY)
  @JoinColumn(name = "adv_id", nullable = false)
  private Advertisement adv_dtls;


}
