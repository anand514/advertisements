package com.sbp.splitbills.advertisement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AdvertisementApplicationTests {

	@Test
	void contextLoads() {
	}

}
