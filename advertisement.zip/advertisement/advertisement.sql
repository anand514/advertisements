-- Table: advertisement.adv_dtls

-- DROP TABLE advertisement.adv_dtls;

CREATE TABLE IF NOT EXISTS advertisement.adv_dtls
(
    adv_dtls_id bigint NOT NULL GENERATED ALWAYS AS IDENTITY ( INCREMENT 1 START 1 MINVALUE 1 MAXVALUE 9223372036854775807 CACHE 1 ),
    name character varying(100) COLLATE pg_catalog."default" NOT NULL,
    description character varying(250) COLLATE pg_catalog."default",
    start_date timestamp without time zone NOT NULL,
    end_date timestamp without time zone NOT NULL,
    advertisement_type_id bigint NOT NULL,
    url_flag "char" NOT NULL,
    url character varying COLLATE pg_catalog."default",
    priority bigint,
    promo_type_id bigint,
    create_date timestamp without time zone,
    updated_date timestamp without time zone,
    created_by character varying(50) COLLATE pg_catalog."default",
    updated_by character varying(50) COLLATE pg_catalog."default",
    CONSTRAINT advertisement_dtls_pkey PRIMARY KEY (adv_dtls_id),
    CONSTRAINT adv_type_fk FOREIGN KEY (advertisement_type_id)
        REFERENCES advertisement.master_types (master_type_id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
)
WITH (
    OIDS = FALSE
)
TABLESPACE pg_default;

ALTER TABLE advertisement.adv_dtls
    OWNER to postgres;

-- Table: advertisement.adv_images

-- DROP TABLE advertisement.adv_images;

CREATE TABLE IF NOT EXISTS advertisement.adv_images
(
    adv_images_id bigint NOT NULL GENERATED ALWAYS AS IDENTITY ( INCREMENT 1 START 1 MINVALUE 1 MAXVALUE 9223372036854775807 CACHE 1 ),
    adv_id bigint NOT NULL,
    image_ref character varying(400) COLLATE pg_catalog."default" NOT NULL,
    create_date timestamp without time zone,
    updated_date timestamp without time zone,
    created_by character varying(50) COLLATE pg_catalog."default",
    updated_by character varying(50) COLLATE pg_catalog."default",
    CONSTRAINT advertisement_images_pkey PRIMARY KEY (adv_images_id),
    CONSTRAINT adv_fk FOREIGN KEY (adv_id)
        REFERENCES advertisement.adv_dtls (adv_dtls_id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
)
WITH (
    OIDS = FALSE
)
TABLESPACE pg_default;

ALTER TABLE advertisement.adv_images
    OWNER to postgres;

-- Table: advertisement.adv_page_holder_mapper

-- DROP TABLE advertisement.adv_page_holder_mapper;

CREATE TABLE IF NOT EXISTS advertisement.adv_page_holder_mapper
(
    adv_page_holder_mapper_id bigint NOT NULL GENERATED ALWAYS AS IDENTITY ( INCREMENT 1 START 1 MINVALUE 1 MAXVALUE 9223372036854775807 CACHE 1 ),
    adv_id bigint NOT NULL,
    page_adv_holder_id bigint NOT NULL,
    create_date time without time zone,
    updated_date time without time zone,
    created_by character varying COLLATE pg_catalog."default",
    updated_by character varying COLLATE pg_catalog."default",
    CONSTRAINT adv_page_holder_mapper_pkey PRIMARY KEY (adv_page_holder_mapper_id),
    CONSTRAINT adv_fk FOREIGN KEY (adv_id)
        REFERENCES advertisement.adv_dtls (adv_dtls_id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION,
    CONSTRAINT page_holder_fk FOREIGN KEY (page_adv_holder_id)
        REFERENCES advertisement.page_adv_holder (page_adv_id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
)
WITH (
    OIDS = FALSE
)
TABLESPACE pg_default;

ALTER TABLE advertisement.adv_page_holder_mapper
    OWNER to postgres;
    
-- Table: advertisement.adv_page_holder_mapper

-- DROP TABLE advertisement.adv_page_holder_mapper;

CREATE TABLE IF NOT EXISTS advertisement.adv_page_holder_mapper
(
    adv_page_holder_mapper_id bigint NOT NULL GENERATED ALWAYS AS IDENTITY ( INCREMENT 1 START 1 MINVALUE 1 MAXVALUE 9223372036854775807 CACHE 1 ),
    adv_id bigint NOT NULL,
    page_adv_holder_id bigint NOT NULL,
    create_date time without time zone,
    updated_date time without time zone,
    created_by character varying COLLATE pg_catalog."default",
    updated_by character varying COLLATE pg_catalog."default",
    CONSTRAINT adv_page_holder_mapper_pkey PRIMARY KEY (adv_page_holder_mapper_id),
    CONSTRAINT adv_fk FOREIGN KEY (adv_id)
        REFERENCES advertisement.adv_dtls (adv_dtls_id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION,
    CONSTRAINT page_holder_fk FOREIGN KEY (page_adv_holder_id)
        REFERENCES advertisement.page_adv_holder (page_adv_id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
)
WITH (
    OIDS = FALSE
)
TABLESPACE pg_default;

ALTER TABLE advertisement.adv_page_holder_mapper
    OWNER to postgres;

-- Table: advertisement.adv_pincodes

-- DROP TABLE advertisement.adv_pincodes;

CREATE TABLE IF NOT EXISTS advertisement.adv_pincodes
(
    adv_pincodes_id bigint NOT NULL GENERATED ALWAYS AS IDENTITY ( INCREMENT 1 START 1 MINVALUE 1 MAXVALUE 9223372036854775807 CACHE 1 ),
    adv_id bigint NOT NULL,
    pincode character varying(50) COLLATE pg_catalog."default" NOT NULL,
    create_date time without time zone,
    updated_date timestamp without time zone,
    created_by character varying COLLATE pg_catalog."default",
    updated_by character varying COLLATE pg_catalog."default",
    CONSTRAINT adv_pincode_mapper_pkey PRIMARY KEY (adv_pincodes_id),
    CONSTRAINT adv_fk FOREIGN KEY (adv_id)
        REFERENCES advertisement.adv_dtls (adv_dtls_id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
)
WITH (
    OIDS = FALSE
)
TABLESPACE pg_default;

ALTER TABLE advertisement.adv_pincodes
    OWNER to postgres;

-- Table: advertisement.adv_promocodes

-- DROP TABLE advertisement.adv_promocodes;

CREATE TABLE IF NOT EXISTS advertisement.adv_promocodes
(
    adv_promocodes_id bigint NOT NULL GENERATED ALWAYS AS IDENTITY ( INCREMENT 1 START 1 MINVALUE 1 MAXVALUE 9223372036854775807 CACHE 1 ),
    adv_id bigint NOT NULL,
    promo_code bigint NOT NULL,
    mapped_user_id bigint,
    create_date timestamp without time zone,
    updated_date timestamp without time zone,
    created_by character varying(50) COLLATE pg_catalog."default",
    updated_by character varying(50) COLLATE pg_catalog."default",
    CONSTRAINT advertisement_promocodes_pkey PRIMARY KEY (adv_promocodes_id),
    CONSTRAINT adv_fk FOREIGN KEY (adv_id)
        REFERENCES advertisement.adv_dtls (adv_dtls_id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
)
WITH (
    OIDS = FALSE
)
TABLESPACE pg_default;

ALTER TABLE advertisement.adv_promocodes
    OWNER to postgres;

-- Table: advertisement.adv_user_type_mapper

-- DROP TABLE advertisement.adv_user_type_mapper;

CREATE TABLE IF NOT EXISTS advertisement.adv_user_type_mapper
(
    adv_user_type_mapper_id bigint NOT NULL GENERATED ALWAYS AS IDENTITY ( INCREMENT 1 START 1 MINVALUE 1 MAXVALUE 9223372036854775807 CACHE 1 ),
    adv_id bigint NOT NULL,
    user_type_id bigint NOT NULL,
    create_date timestamp without time zone,
    updated_date timestamp without time zone,
    created_by character varying(50) COLLATE pg_catalog."default",
    updated_by character varying(50) COLLATE pg_catalog."default",
    CONSTRAINT adv_user_type_mapper_pkey PRIMARY KEY (adv_user_type_mapper_id),
    CONSTRAINT adv_fk FOREIGN KEY (adv_id)
        REFERENCES advertisement.adv_dtls (adv_dtls_id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION,
    CONSTRAINT user_type_fk FOREIGN KEY (user_type_id)
        REFERENCES advertisement.master_types (master_type_id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
)
WITH (
    OIDS = FALSE
)
TABLESPACE pg_default;

ALTER TABLE advertisement.adv_user_type_mapper
    OWNER to postgres;

-- Table: advertisement.master_types

-- DROP TABLE advertisement.master_types;

CREATE TABLE IF NOT EXISTS advertisement.master_types
(
    master_type_id bigint NOT NULL GENERATED ALWAYS AS IDENTITY ( INCREMENT 1 START 1 MINVALUE 1 MAXVALUE 9223372036854775807 CACHE 1 ),
    name character varying(50) COLLATE pg_catalog."default" NOT NULL,
    description character varying(100) COLLATE pg_catalog."default" NOT NULL,
    reference_type character varying(100) COLLATE pg_catalog."default" NOT NULL,
    module character varying(100) COLLATE pg_catalog."default",
    status boolean DEFAULT true,
    CONSTRAINT master_types_pkey PRIMARY KEY (master_type_id)
)
WITH (
    OIDS = FALSE
)
TABLESPACE pg_default;

ALTER TABLE advertisement.master_types
    OWNER to postgres;

-- Table: advertisement.page_adv_holder

-- DROP TABLE advertisement.page_adv_holder;

CREATE TABLE IF NOT EXISTS advertisement.page_adv_holder
(
    page_adv_id bigint NOT NULL GENERATED ALWAYS AS IDENTITY ( INCREMENT 1 START 1 MINVALUE 1 MAXVALUE 9223372036854775807 CACHE 1 ),
    page_id bigint NOT NULL,
    adv_type_id bigint NOT NULL,
    bracket_width double precision,
    bracket_height double precision,
    create_date timestamp without time zone,
    updated_date timestamp without time zone,
    created_by character varying(50) COLLATE pg_catalog."default",
    updated_by character(50) COLLATE pg_catalog."default",
    CONSTRAINT page_adv_holder_pkey PRIMARY KEY (page_adv_id),
    CONSTRAINT adv_type_fk FOREIGN KEY (adv_type_id)
        REFERENCES advertisement.master_types (master_type_id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION,
    CONSTRAINT page_master_fk FOREIGN KEY (page_id)
        REFERENCES advertisement.page_master (page_master_id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
)
WITH (
    OIDS = FALSE
)
TABLESPACE pg_default;

ALTER TABLE advertisement.page_adv_holder
    OWNER to postgres;

-- Table: advertisement.page_master

-- DROP TABLE advertisement.page_master;

CREATE TABLE IF NOT EXISTS advertisement.page_master
(
    page_master_id bigint NOT NULL GENERATED ALWAYS AS IDENTITY ( INCREMENT 1 START 1 MINVALUE 1 MAXVALUE 9223372036854775807 CACHE 1 ),
    page_name character varying(25) COLLATE pg_catalog."default" NOT NULL,
    description character varying(100) COLLATE pg_catalog."default",
    create_date time without time zone,
    updated_date time without time zone,
    created_by bigint,
    updated_by bigint,
    CONSTRAINT page_info_pkey PRIMARY KEY (page_master_id)
)
WITH (
    OIDS = FALSE
)
TABLESPACE pg_default;

ALTER TABLE advertisement.page_master
    OWNER to postgres;